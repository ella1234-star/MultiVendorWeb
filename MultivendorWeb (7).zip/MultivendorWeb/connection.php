<?php
$con = mysqli_connect("localhost" ,"learnexu_pres776" ,'Johnson1976' , 'learnexu_multivendors');
?>