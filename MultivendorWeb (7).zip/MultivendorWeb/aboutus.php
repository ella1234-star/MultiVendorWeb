<?php
include("head.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>About US</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="css/footerStyle.css">
    <style>
body{
    background-color:#99e599 ;

}
    </style>
</head>


<body>

<br><br><br>

<center><h1>About US</h1></center>

<br><br><br>
<br><br><br>
<br><br><br>
<br><br><br>
<br><br><br>
<br><br><br>
<?php
include("footer1.php");
?>
</body>
</html>