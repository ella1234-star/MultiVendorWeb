<footer class="footer-section">
        <div class="container">
           
        <div class="copyright-area">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6 col-lg-6 text-center text-lg-left">
                        <div class="copyright-text">
                            <p>  Copyright © <?php echo date("Y");?> Whathappeningsir &copy;  All Right Reserved </p>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 d-none d-lg-block text-right">
                        <div class="footer-menu">
                            <ul>
                            <li><a href="terms and condition.php">T&Cs</a></li>
                                <li><a href="disclaimer.php">Disclaimer</a></li>
                                <li><a href="#">Privacy Policy</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
